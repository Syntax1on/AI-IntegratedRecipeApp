
# AI Recipe App 🧑‍🍳✨

Generate smart and creative recipes using GPT-4 based on the ingredients you have at home.
