
from flask import Flask, render_template, request
import openai, os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    recipe = ""
    if request.method == "POST":
        ingredients = request.form["ingredients"]
        prompt = f"Suggest a recipe using: {ingredients}"
        response = openai.Completion.create(
            engine="gpt-3.5-turbo-instruct",
            prompt=prompt,
            max_tokens=200
        )
        recipe = response["choices"][0]["text"].strip()
    return render_template("index.html", recipe=recipe)

if __name__ == "__main__":
    app.run(debug=True)
